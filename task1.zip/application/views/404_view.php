<section class="content">
		<div class="title">
			<h1 class="h1">Помилка 404! Сервер не розпізнав запит.</h1>
		</div>
</section>
<script>
$( document ).ready(function() {
    setTimeout(function() {
		window.location.href = '/';
	}, 5000);
});
</script>